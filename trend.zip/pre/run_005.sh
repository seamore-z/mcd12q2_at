#!/bin/bash

echo Submitting $1
R --vanilla < /usr3/graduate/mkmoon/GitHub/TAscience/trend/005_nbar_ts.R $1


