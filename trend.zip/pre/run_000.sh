#!/bin/bash

echo Submitting $1
R --vanilla < /usr3/graduate/mkmoon/GitHub/TAscience/trend/pre/000_get_q2.R $1


