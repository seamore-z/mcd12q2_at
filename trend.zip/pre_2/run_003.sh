#!/bin/bash

echo Submitting $1
R --vanilla < /usr3/graduate/mkmoon/GitHub/TAscience/trend/003_ht.R $1


