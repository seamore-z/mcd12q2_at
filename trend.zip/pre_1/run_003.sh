#!/bin/bash

echo Submitting $1
R --vanilla < /usr3/graduate/mkmoon/GitHub/TAscience/trend/pre_1/003_cal_change_climate.R $1


