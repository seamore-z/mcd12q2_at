#!/bin/bash

echo Submitting $1
R --vanilla < /usr3/graduate/mkmoon/GitHub/TAscience/trend/nbar/get_MCD43A2.R $1


